﻿using System;
using System.Collections.Generic;

namespace Lesson10FP.Models
{
    public partial class artists
    {
        public artists()
        {
            albums = new HashSet<albums>();
        }

        public long ArtistId { get; set; }
        public string Name { get; set; }

        public virtual ICollection<albums> albums { get; set; }
    }
}
