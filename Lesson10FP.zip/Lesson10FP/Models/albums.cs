﻿using System;
using System.Collections.Generic;

namespace Lesson10FP.Models
{
    public partial class albums
    {
        public albums()
        {
            tracks = new HashSet<tracks>();
        }

        public long AlbumId { get; set; }
        public string Title { get; set; }
        public long ArtistId { get; set; }

        public virtual artists Artist { get; set; }
        public virtual ICollection<tracks> tracks { get; set; }
    }
}
